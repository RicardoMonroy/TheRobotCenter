<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            @include('admin.menu')
        </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div>
