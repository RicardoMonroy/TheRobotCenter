
<div class="footer-bottom">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 text-center"> 2019 The Robot Center</div>
        </div>
    </div>
</div>
<?php /**PATH /home/ricardo/Laravel/TheRobotCenter/resources/views/layouts/footer.blade.php ENDPATH**/ ?>