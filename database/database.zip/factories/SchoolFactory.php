<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\School;
use Faker\Generator as Faker;

$factory->define(School::class, function (Faker $faker) {
    return [
        //
    ];
});
