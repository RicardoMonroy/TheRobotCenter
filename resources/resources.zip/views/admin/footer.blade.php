<div>
    <a href="#">CeroUnoLabs</a>
    <span>&copy; 2018.</span>
</div>
<div class="ml-auto">
    <span>Hecho por</span>
    <a href="#">Ricardo Monroy</a>
</div>
